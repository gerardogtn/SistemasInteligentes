class Drawable(object):
  """ An object that can be drawn into a canvas."""
  def draw(self, canvas):
    pass