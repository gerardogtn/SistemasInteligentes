
class Explorer(object):
  # TODO:
  pass